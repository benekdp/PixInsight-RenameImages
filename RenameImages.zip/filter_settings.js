var filterSettings = {
    LUMINANCE: "Luminance",
    RED: "Red",
    GREEN: "Green",
    BLUE: "Blue",
    SULFUR: "Sulfur",
    HYDROGEN: "HydrogenAlpha",
    OXYGEN: "Oxygen"
};